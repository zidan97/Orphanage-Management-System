-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2023 at 02:12 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orphanage`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `subject`, `message`) VALUES
('test', 'test@gmail.com', 'qw', 'fff');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `historyID` int(40) NOT NULL,
  `itemName` varchar(40) NOT NULL,
  `itemQuantity` int(40) NOT NULL,
  `unit` varchar(40) NOT NULL,
  `category` varchar(40) NOT NULL,
  `dates` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`historyID`, `itemName`, `itemQuantity`, `unit`, `category`, `dates`) VALUES
(1, 'orange', 4, 'packet', 'food', '2023-01-02'),
(2, 'ayam', 4, 'kg', 'food', '2023-01-02'),
(3, 'ikan haruan', 3, 'kg', 'food', '2023-01-02');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventoryID` int(40) NOT NULL,
  `itemNames` varchar(40) NOT NULL,
  `quantity` int(40) NOT NULL,
  `category` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventoryID`, `itemNames`, `quantity`, `category`) VALUES
(1, 'ayam', 7, 'food');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `category` varchar(40) NOT NULL,
  `status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `username`, `password`, `email`, `category`, `status`) VALUES
(1, 'zidan', 'test123', 'zidan01@gmail.com', 'admin', 'verify'),
(2, 'raudhatulMaryam', 'test1', 'raudhatul@gmail.com', 'orphanage', 'verify'),
(3, 'rafly', 'test', 'rafly01@gmail.com', 'donor', 'verify'),
(4, 'yusri', 'test1', 'yusri01@gmail.com', 'donor', 'verify'),
(5, 'fazli', 'test', 'fazli01@gmail.com', 'donor', 'verify'),
(6, 'imran', 'test', 'imran01@gmail.com', 'donor', 'verify'),
(7, 'mirasy', 'test', 'mirasy01@gmail.com', 'donor', '');

-- --------------------------------------------------------

--
-- Table structure for table `requestitem`
--

CREATE TABLE `requestitem` (
  `itemId` int(10) NOT NULL,
  `itemName` varchar(100) NOT NULL,
  `itemQuantity` int(200) NOT NULL,
  `unit` varchar(40) NOT NULL,
  `category` varchar(100) NOT NULL,
  `dates` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `requestitem`
--

INSERT INTO `requestitem` (`itemId`, `itemName`, `itemQuantity`, `unit`, `category`, `dates`) VALUES
(1, 'minyak', 3, 'bottle', 'food', '2023-01-02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`historyID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventoryID`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `requestitem`
--
ALTER TABLE `requestitem`
  ADD PRIMARY KEY (`itemId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `historyID` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventoryID` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `requestitem`
--
ALTER TABLE `requestitem`
  MODIFY `itemId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
