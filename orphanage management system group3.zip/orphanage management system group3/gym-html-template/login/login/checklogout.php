<?php 
session_start(); // Start up your PHP Session
 

?>

<html>
	<head><title>Viewing Student Data</title>
    
    <link rel="stylesheet" href="style.css">

    <head>
<body>
<?php 

 

?>

</body>
